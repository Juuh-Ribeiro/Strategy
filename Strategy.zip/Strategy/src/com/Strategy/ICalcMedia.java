package com.Strategy;

public interface ICalcMedia {

    double calculaMedia(double p1, double p2);
    String Situacao(double media);
}
